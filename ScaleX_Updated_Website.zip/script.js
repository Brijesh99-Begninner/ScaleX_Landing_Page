(function () {
  "use strict";

  /* ============ Year in footer ============ */
  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ============ Sticky header ============ */
  var header = document.getElementById("siteHeader");
  var backToTop = document.getElementById("backToTop");
  var progressBar = document.getElementById("scrollProgress");

  function onScroll() {
    var y = window.scrollY || window.pageYOffset;
    if (header) header.classList.toggle("is-scrolled", y > 40);
    if (backToTop) backToTop.classList.toggle("is-visible", y > 700);

    var docHeight = document.documentElement.scrollHeight - window.innerHeight;
    var pct = docHeight > 0 ? (y / docHeight) * 100 : 0;
    if (progressBar) progressBar.style.width = pct + "%";
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  if (backToTop) {
    backToTop.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  /* ============ Mobile nav toggle ============ */
  var navToggle = document.getElementById("navToggle");
  var mainNav = document.getElementById("mainNav");
  if (navToggle && mainNav) {
    navToggle.addEventListener("click", function () {
      var open = mainNav.classList.toggle("is-open");
      navToggle.classList.toggle("is-open", open);
      navToggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    mainNav.querySelectorAll(".nav-link").forEach(function (link) {
      link.addEventListener("click", function () {
        mainNav.classList.remove("is-open");
        navToggle.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  /* ============ Scroll reveal ============ */
  var revealEls = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: "0px 0px -60px 0px" }
    );
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add("is-visible"); });
  }

  /* ============ Process timeline scroll progress ============ */
  var timeline = document.getElementById("timeline");
  var timelineProgress = document.getElementById("timelineProgress");
  if (timeline && timelineProgress) {
    function updateTimeline() {
      var rect = timeline.getBoundingClientRect();
      var vh = window.innerHeight;
      var total = rect.height + vh * 0.5;
      var covered = vh * 0.75 - rect.top;
      var pct = Math.max(0, Math.min(1, covered / total));
      timelineProgress.style.width = (pct * 100) + "%";
    }
    window.addEventListener("scroll", updateTimeline, { passive: true });
    window.addEventListener("resize", updateTimeline);
    updateTimeline();
  }

  /* ============ Testimonial carousel controls ============ */
  var testiTrack = document.querySelector(".testi-track");
  var prevBtn = document.getElementById("testiPrev");
  var nextBtn = document.getElementById("testiNext");
  if (testiTrack && prevBtn && nextBtn) {
    function cardStep() {
      var card = testiTrack.querySelector(".testi-card");
      if (!card) return 320;
      var style = window.getComputedStyle(testiTrack);
      var gap = parseFloat(style.columnGap || style.gap || 24);
      return card.getBoundingClientRect().width + gap;
    }
    prevBtn.addEventListener("click", function () {
      testiTrack.scrollBy({ left: -cardStep(), behavior: "smooth" });
    });
    nextBtn.addEventListener("click", function () {
      testiTrack.scrollBy({ left: cardStep(), behavior: "smooth" });
    });
  }

  /* ============ Section-aware navigation ============ */
  var sectionLinks = document.querySelectorAll('.main-nav .nav-link');
  var sectionTargets = Array.prototype.map.call(sectionLinks, function (link) {
    return document.querySelector(link.getAttribute('href'));
  }).filter(Boolean);
  if ('IntersectionObserver' in window && sectionTargets.length) {
    var navObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        sectionLinks.forEach(function (link) {
          link.classList.toggle('is-current', link.getAttribute('href') === '#' + entry.target.id);
        });
      });
    }, { rootMargin: '-30% 0px -60% 0px', threshold: 0 });
    sectionTargets.forEach(function (section) { navObserver.observe(section); });
  }

  /* ============ Subtle hero depth ============ */
  var hero = document.querySelector('.hero');
  var heroVisual = document.querySelector('.hero-visual');
  var watermark = document.querySelector('.hero-watermark');
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (hero && heroVisual && !reduceMotion && window.matchMedia('(min-width: 881px)').matches) {
    hero.addEventListener('mousemove', function (event) {
      var rect = hero.getBoundingClientRect();
      var x = (event.clientX - rect.left) / rect.width - 0.5;
      var y = (event.clientY - rect.top) / rect.height - 0.5;
      heroVisual.style.transform = 'translate3d(' + (x * -10) + 'px,' + (y * -8) + 'px,0)';
      if (watermark) watermark.style.transform = 'translate3d(' + (x * 14) + 'px,' + (y * 10) + 'px,0)';
    });
    hero.addEventListener('mouseleave', function () {
      heroVisual.style.transform = '';
      if (watermark) watermark.style.transform = '';
    });
  }

  /* ============ Smooth-scroll offset correction for hash links ============ */
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener("click", function (e) {
      var id = a.getAttribute("href");
      if (id.length < 2) return;
      var target = document.querySelector(id);
      if (!target) return;
      e.preventDefault();
      var top = target.getBoundingClientRect().top + window.pageYOffset - 82;
      window.scrollTo({ top: top, behavior: "smooth" });
    });
  });
})();
